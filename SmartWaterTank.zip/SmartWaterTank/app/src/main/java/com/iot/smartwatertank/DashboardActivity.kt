package com.iot.smartwatertank

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.iot.smartwatertank.databinding.ActivityDashboardBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val db by lazy { AppDatabase.getDatabase(this) }
    private val TAG = "Dashboard"

    private enum class ViewMode { DAILY, WEEKLY, MONTHLY }
    private var currentViewMode = ViewMode.DAILY
    private var allEvents: List<PumpEvent> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        setupBottomNavigation()

        binding.chipGroupView.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                currentViewMode = when (checkedIds.first()) {
                    R.id.chipWeekly -> ViewMode.WEEKLY
                    R.id.chipMonthly -> ViewMode.MONTHLY
                    else -> ViewMode.DAILY
                }
                updateChart()
            }
        }

        lifecycleScope.launch {
            allEvents = db.pumpEventDao().getAllEvents().first()
            Log.d(TAG, "Fetched ${allEvents.size} total events from database.")
            updateUiWithEvents()
        }
    }

    override fun onResume() {
        super.onResume()
        binding.bottomNavigation.selectedItemId = R.id.navigation_dashboard
    }

    private fun updateUiWithEvents() {
        displayTodaysSummary(allEvents)
        updateChart()
    }

    private fun updateChart() {
        when (currentViewMode) {
            ViewMode.DAILY -> {
                binding.textViewChartTitle.text = "Today (Hour-by-Hour)"
                val dailyData = processEventsForDailyChart(allEvents)
                setupBarChart(dailyData.entries, dailyData.labels)
            }
            ViewMode.WEEKLY -> {
                binding.textViewChartTitle.text = "Last 7 Days"
                val weeklyData = processEventsForTimeFrame(allEvents, 7)
                setupBarChart(weeklyData.entries, weeklyData.labels)
            }
            ViewMode.MONTHLY -> {
                binding.textViewChartTitle.text = "Last 30 Days"
                val monthlyData = processEventsForTimeFrame(allEvents, 30)
                setupBarChart(monthlyData.entries, monthlyData.labels)
            }
        }
    }

    private fun displayTodaysSummary(events: List<PumpEvent>) {
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val todayEvents = events.filter { it.timestamp >= todayStart }

        var totalOnTimeMillis: Long = 0
        var pumpCycles = 0
        var lastOnTimestamp: Long? = null
        val sortedEvents = todayEvents.sortedBy { it.timestamp }

        for (event in sortedEvents) {
            if (event.status == "ON") {
                pumpCycles++
                if (lastOnTimestamp == null) {
                    lastOnTimestamp = event.timestamp
                }
            } else if (event.status == "OFF" && lastOnTimestamp != null) {
                totalOnTimeMillis += (event.timestamp - lastOnTimestamp)
                lastOnTimestamp = null
            }
        }

        val totalOnTimeMinutes = TimeUnit.MILLISECONDS.toMinutes(totalOnTimeMillis)
        binding.textViewTotalTimeValue.text = "$totalOnTimeMinutes mins"
        binding.textViewCyclesValue.text = "$pumpCycles times"
    }

    private fun processEventsForDailyChart(events: List<PumpEvent>): ChartData {
        val hourlyUsage = LongArray(24) { 0L }
        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val todayEvents = events.filter { it.timestamp >= todayStart }
        var lastOnTimestamp: Long? = null
        val sortedEvents = todayEvents.sortedBy { it.timestamp }

        for (event in sortedEvents) {
            if (event.status == "ON") {
                if (lastOnTimestamp == null) {
                    lastOnTimestamp = event.timestamp
                }
            } else if (event.status == "OFF" && lastOnTimestamp != null) {
                val duration = event.timestamp - lastOnTimestamp
                val cal = Calendar.getInstance().apply { timeInMillis = lastOnTimestamp!! }
                val hour = cal.get(Calendar.HOUR_OF_DAY)
                hourlyUsage[hour] += duration
                lastOnTimestamp = null
            }
        }

        val labels = (0..23).map { hour ->
            when {
                hour == 0 -> "12am"
                hour < 12 -> "${hour}am"
                hour == 12 -> "12pm"
                else -> "${hour - 12}pm"
            }
        }
        val entries = hourlyUsage.mapIndexed { hour, millis ->
            val usageMinutes = TimeUnit.MILLISECONDS.toMinutes(millis).toFloat()
            BarEntry(hour.toFloat(), usageMinutes)
        }
        return ChartData(entries, labels)
    }

    private fun processEventsForTimeFrame(events: List<PumpEvent>, days: Int): ChartData {
        val dailyUsage = mutableMapOf<String, Long>()
        val timeLimit = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -days) }.timeInMillis
        val recentEvents = events.filter { it.timestamp >= timeLimit }
        var lastOnTimestamp: Long? = null
        val sortedEvents = recentEvents.sortedBy { it.timestamp }

        for (event in sortedEvents) {
            if (event.status == "ON") {
                lastOnTimestamp = event.timestamp
            } else if (event.status == "OFF" && lastOnTimestamp != null) {
                val duration = event.timestamp - lastOnTimestamp
                val dayKey = SimpleDateFormat("MMM d", Locale.US).format(Date(lastOnTimestamp))
                dailyUsage[dayKey] = (dailyUsage[dayKey] ?: 0L) + duration
                lastOnTimestamp = null
            }
        }

        val labels = mutableListOf<String>()
        val entries = mutableListOf<BarEntry>()
        for (i in (days - 1) downTo 0) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val dayKey = SimpleDateFormat("MMM d", Locale.US).format(cal.time)
            labels.add(dayKey)
            val usageMinutes = TimeUnit.MILLISECONDS.toMinutes(dailyUsage[dayKey] ?: 0L).toFloat()
            entries.add(BarEntry((days - 1 - i).toFloat(), usageMinutes))
        }

        return ChartData(entries, labels)
    }

    private fun setupBarChart(entries: List<BarEntry>, labels: List<String>) {
        // --- MODIFIED: Use ContextCompat.getColor for reliability ---
        val barColor = ContextCompat.getColor(this, R.color.primaryColor)
        val textColor = ContextCompat.getColor(this, R.color.textColorPrimary)
        val secondaryTextColor = ContextCompat.getColor(this, R.color.textColorSecondary)

        val dataSet = BarDataSet(entries, "Pump Usage (Minutes)")
        dataSet.color = barColor
        dataSet.valueTextColor = textColor
        dataSet.valueTextSize = 10f

        binding.barChart.data = BarData(dataSet)
        binding.barChart.description.isEnabled = false
        binding.barChart.setFitBars(true)
        binding.barChart.legend.isEnabled = false

        val xAxis = binding.barChart.xAxis
        xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)
        xAxis.textColor = secondaryTextColor

        xAxis.setLabelCount(if (labels.size > 10) 6 else labels.size, false)

        binding.barChart.axisLeft.textColor = secondaryTextColor
        binding.barChart.axisLeft.axisMinimum = 0f
        binding.barChart.axisLeft.setDrawGridLines(false)
        binding.barChart.axisRight.isEnabled = false

        binding.barChart.animateY(1000)
        binding.barChart.invalidate()
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.selectedItemId = R.id.navigation_dashboard
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    startActivity(intent)
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.navigation_dashboard -> {
                    true
                }
                R.id.navigation_settings -> {
                    val intent = Intent(this, SettingsActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    startActivity(intent)
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }
    }

    data class ChartData(val entries: List<BarEntry>, val labels: List<String>)
}