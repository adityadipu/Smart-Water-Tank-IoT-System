package com.iot.smartwatertank

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.gson.Gson
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.UUID

class MqttService : Service() {

    private lateinit var mqttClient: Mqtt5AsyncClient
    private val binder = MqttBinder()
    private val TAG = "MqttService"

    // --- Store the latest tank data ---
    private var latestTankData: TankData? = null

    // Connection state
    private var isConnected = false

    // Your existing constants and variables
    private val LOW_LEVEL_THRESHOLD = 20
    private val HIGH_LEVEL_THRESHOLD = 80
    private val ALERT_NOTIFICATION_CHANNEL_ID = "water_tank_alerts"
    private val ALERT_NOTIFICATION_ID = 1
    private val FOREGROUND_NOTIFICATION_CHANNEL_ID = "mqtt_service_status"
    private val FOREGROUND_NOTIFICATION_ID = 2
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private val db by lazy { AppDatabase.getDatabase(this) }
    private var lastLowAlertSent = false
    private var lastHighAlertSent = false

    // 🔥 FIX: Track pump state properly
    private var pumpOnTimestamp: Long = 0L
    private var isPumpRunning = false

    inner class MqttBinder : Binder() {
        fun getService(): MqttService = this@MqttService
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = createForegroundNotification()
        startForeground(FOREGROUND_NOTIFICATION_ID, notification)
        connect()
        return START_STICKY
    }

    private fun createForegroundNotification(): Notification {
        val channelId = FOREGROUND_NOTIFICATION_CHANNEL_ID
        val channelName = "Smart Tank Service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, channelName, NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Smart Water Tank")
            .setContentText("Monitoring water level in the background")
            .setSmallIcon(R.drawable.ic_water_drop)
            .setOngoing(true)
            .build()
    }

    private fun connect() {
        if (::mqttClient.isInitialized && mqttClient.state.isConnectedOrReconnect) {
            return
        }
        mqttClient = MqttClient.builder()
            .useMqttVersion5()
            .identifier("AndroidApp-${UUID.randomUUID()}")
            .serverHost(MqttConstants.SERVER_URI)
            .serverPort(MqttConstants.PORT)
            .automaticReconnectWithDefaultConfig()
            .buildAsync()

        mqttClient.connectWith()
            .simpleAuth()
            .username(MqttConstants.USERNAME)
            .password(MqttConstants.PASSWORD.toByteArray())
            .applySimpleAuth()
            .send()
            .whenComplete { _, throwable ->
                if (throwable != null) {
                    isConnected = false
                    broadcastConnectionStatus(false, "Connection Failed")
                } else {
                    isConnected = true
                    subscribeToTopics()
                    broadcastConnectionStatus(true, "Connected")
                }
            }
    }

    fun requestStatusUpdate() {
        val message = if (isConnected) "Connected" else "Disconnected"
        broadcastConnectionStatus(isConnected, message)

        // Send the latest tank data if we have it
        latestTankData?.let { tankData ->
            val payload = Gson().toJson(tankData)
            val intent = Intent(MqttConstants.ACTION_MQTT_MSG_RECEIVED).apply {
                putExtra(MqttConstants.EXTRA_MESSAGE, payload)
                // 🔥 FIX: Send the actual pump ON timestamp
                putExtra(MqttConstants.EXTRA_PUMP_ON_TIMESTAMP, pumpOnTimestamp)
            }
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        }
    }

    private fun subscribeToTopics() {
        mqttClient.subscribeWith()
            .topicFilter(MqttConstants.SUB_TOPIC_DATA)
            .callback { publish ->
                val payload = String(publish.payloadAsBytes)
                handleIncomingMessage(payload)
            }
            .send()
    }

    private fun handleIncomingMessage(payload: String) {
        // Store the latest tank data
        try {
            latestTankData = Gson().fromJson(payload, TankData::class.java)
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing tank data", e)
        }

        try {
            val tankData = Gson().fromJson(payload, TankData::class.java)

            // 🔥 FIX: Proper pump state tracking
            if (tankData.pump_status == "ON" && !isPumpRunning) {
                // Pump just turned ON - record the timestamp
                pumpOnTimestamp = System.currentTimeMillis()
                isPumpRunning = true
                Log.d(TAG, "Pump turned ON at: $pumpOnTimestamp")
            } else if (tankData.pump_status == "OFF" && isPumpRunning) {
                // Pump turned OFF - reset
                pumpOnTimestamp = 0L
                isPumpRunning = false
                Log.d(TAG, "Pump turned OFF")
            }

            val intent = Intent(MqttConstants.ACTION_MQTT_MSG_RECEIVED).apply {
                putExtra(MqttConstants.EXTRA_MESSAGE, payload)
                // 🔥 FIX: Send the actual pump ON timestamp (not current time)
                putExtra(MqttConstants.EXTRA_PUMP_ON_TIMESTAMP, pumpOnTimestamp)
            }
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent)

            serviceScope.launch {
                db.pumpEventDao().insert(
                    PumpEvent(
                        timestamp = System.currentTimeMillis(),
                        status = tankData.pump_status
                    )
                )
            }
            checkAndSendNotifications(tankData.level_percentage)
        } catch (e: Exception) {
            Log.e(TAG, "Error processing incoming message payload", e)
        }
    }

    fun publish(topic: String, message: String) {
        if (::mqttClient.isInitialized && mqttClient.state.isConnected) {
            mqttClient.publishWith().topic(topic).payload(message.toByteArray()).send()
        }
    }

    private fun broadcastConnectionStatus(isConnected: Boolean, message: String) {
        val statusIntent = Intent(MqttConstants.ACTION_MQTT_CONNECTION_STATUS).apply {
            putExtra(MqttConstants.EXTRA_CONNECTION_STATUS, isConnected)
            putExtra(MqttConstants.EXTRA_STATUS_MESSAGE, message)
        }
        LocalBroadcastManager.getInstance(this).sendBroadcast(statusIntent)
    }

    private fun checkAndSendNotifications(levelPercentage: Int) {
        when {
            levelPercentage < LOW_LEVEL_THRESHOLD && !lastLowAlertSent -> {
                sendAlertNotification("Water Tank Alert", "Water level is critically low at $levelPercentage%!")
                lastLowAlertSent = true
                lastHighAlertSent = false
            }
            levelPercentage > HIGH_LEVEL_THRESHOLD && !lastHighAlertSent -> {
                sendAlertNotification("Water Tank Alert", "Water tank is full ($levelPercentage%)!")
                lastHighAlertSent = true
                lastLowAlertSent = false
            }
            levelPercentage in (LOW_LEVEL_THRESHOLD + 1) until HIGH_LEVEL_THRESHOLD -> {
                lastLowAlertSent = false
                lastHighAlertSent = false
            }
        }
    }

    private fun sendAlertNotification(title: String, message: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALERT_NOTIFICATION_CHANNEL_ID, "Water Tank Alerts", NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, ALERT_NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_water_drop)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        notificationManager.notify(ALERT_NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::mqttClient.isInitialized) {
            mqttClient.disconnect()
        }
        serviceJob.cancel()
    }
}