package com.iot.smartwatertank

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PumpEventDao {
    @Insert
    suspend fun insert(event: PumpEvent)

    @Query("SELECT * FROM pump_events ORDER BY timestamp DESC")
    fun getAllEvents(): Flow<List<PumpEvent>>
}