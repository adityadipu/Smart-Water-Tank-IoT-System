package com.iot.smartwatertank

object MqttConstants {
    // --- MQTT Broker Details ---
    const val SERVER_URI = "broker.hivemq.com"
    const val PORT = 1883
    const val USERNAME = "" // Add your username if needed
    const val PASSWORD = "" // Add your password if needed

    // --- MQTT Topics ---
    const val SUB_TOPIC_DATA = "iot-projects/water-tank-123/data"
    const val PUB_TOPIC_COMMAND = "iot-projects/water-tank-123/command"
    const val PUB_TOPIC_CONFIG = "iot-projects/water-tank-123/config"

    // --- Broadcast Actions & Extras ---
    const val ACTION_MQTT_CONNECTION_STATUS = "com.iot.smartwatertank.MQTT_CONNECTION_STATUS"
    const val EXTRA_CONNECTION_STATUS = "extra_connection_status"
    const val EXTRA_STATUS_MESSAGE = "extra_status_message"

    const val ACTION_MQTT_MSG_RECEIVED = "com.iot.smartwatertank.MQTT_MSG_RECEIVED"
    const val EXTRA_MESSAGE = "extra_message" // We will send the whole JSON string

    // --- NEW: Add a key for the pump start time ---
    const val EXTRA_PUMP_ON_TIMESTAMP = "extra_pump_on_timestamp"

    // --- SharedPreferences Keys ---
    const val PREFS_NAME = "PumpSettings"
    const val KEY_MIN_LEVEL = "MIN_LEVEL"
    const val KEY_MAX_LEVEL = "MAX_LEVEL"
}