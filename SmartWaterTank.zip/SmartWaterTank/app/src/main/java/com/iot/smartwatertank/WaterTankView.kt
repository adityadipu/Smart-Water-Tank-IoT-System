package com.iot.smartwatertank

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.sin

class WaterTankView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Paints
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 25f // CHANGED: Made the border thicker for a bolder look
        color = ContextCompat.getColor(context, R.color.gray_tank_border)
    }

    private val ridgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 12f // CHANGED: Made ridges thicker to be more visible
        color = ContextCompat.getColor(context, R.color.gray_tank_border)
    }

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.dark_tank_body)
    }

    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.blue_fill)
    }

    private val percentageTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 100f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private val cmTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 55f // CHANGED: Increased text size for better readability
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }

    // Drawing variables
    private val tankRect = RectF() // Outer bounds for calculation
    private val tankShapePath = Path() // Actual path for the tank shape
    private val wavePath = Path()

    // Animation variables
    private var waterLevelPercent = 0f
    private var waterLevelCm = 0f
    private var waveOffset = 0f

    private var levelAnimator: ValueAnimator? = null
    private val waveAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            waveOffset = it.animatedValue as Float
            invalidate()
        }
    }

    // Constants for the new tank shape (water cooler bottle style)
    private val neckWidthRatio = 0.4f     // Neck is 40% of the total width
    private val neckHeightRatio = 0.1f    // Neck is 10% of the total height
    private val shoulderHeightRatio = 0.15f // Shoulders take up 15% of the total height

    init {
        waveAnimator.start()
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val padding = borderPaint.strokeWidth / 2

        // CHANGED: Adjust the tank's overall proportions to be taller and narrower
        val availableWidth = w - padding * 2
        val availableHeight = h - padding * 2

        val tankDisplayWidth = availableWidth * 0.9f // Use 90% of the available width
        val tankDisplayHeight = availableHeight      // Use 100% of the available height

        val left = (w - tankDisplayWidth) / 2f
        val top = (h - tankDisplayHeight) / 2f

        tankRect.set(left, top, left + tankDisplayWidth, top + tankDisplayHeight)
        // --- End of proportion change ---

        tankShapePath.reset()

        val width = tankRect.width()
        val height = tankRect.height()
        val centerX = tankRect.centerX()

        // Define key coordinates for the shape based on ratios
        val neckWidth = width * neckWidthRatio
        val neckLeft = centerX - neckWidth / 2
        val neckRight = centerX + neckWidth / 2
        val neckTopY = tankRect.top
        val neckBottomY = tankRect.top + height * neckHeightRatio

        val shoulderHeight = height * shoulderHeightRatio
        val shoulderTopY = neckBottomY
        val shoulderBottomY = shoulderTopY + shoulderHeight

        val bodyLeft = tankRect.left
        val bodyRight = tankRect.right
        val bodyBottomY = tankRect.bottom

        // --- Build the Tank Path ---
        tankShapePath.moveTo(neckLeft, neckTopY)
        tankShapePath.lineTo(neckRight, neckTopY)
        tankShapePath.lineTo(neckRight, shoulderTopY)
        tankShapePath.quadTo(bodyRight, shoulderTopY, bodyRight, shoulderBottomY)
        tankShapePath.lineTo(bodyRight, bodyBottomY)
        tankShapePath.lineTo(bodyLeft, bodyBottomY)
        tankShapePath.lineTo(bodyLeft, shoulderBottomY)
        tankShapePath.quadTo(bodyLeft, shoulderTopY, neckLeft, shoulderTopY)
        tankShapePath.close()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawPath(tankShapePath, backgroundPaint)

        val bodyTopY = tankRect.top + tankRect.height() * (neckHeightRatio + shoulderHeightRatio)
        val bodyHeight = tankRect.bottom - bodyTopY
        val ridge1Y = bodyTopY + bodyHeight * 0.33f
        val ridge2Y = bodyTopY + bodyHeight * 0.66f
        canvas.drawLine(tankRect.left, ridge1Y, tankRect.right, ridge1Y, ridgePaint)
        canvas.drawLine(tankRect.left, ridge2Y, tankRect.right, ridge2Y, ridgePaint)

        val totalTankHeight = tankRect.height()
        val waterLevelPixelHeight = totalTankHeight * (waterLevelPercent / 100f)
        val waterTopPixelY = tankRect.bottom - waterLevelPixelHeight

        canvas.save()
        canvas.clipPath(tankShapePath)

        if (waterLevelPixelHeight > 0) {
            wavePath.reset()
            val currentTankWidth = calculateTankWidthAtY(waterTopPixelY)
            val currentTankLeft = tankRect.centerX() - currentTankWidth / 2f
            val currentTankRight = tankRect.centerX() + currentTankWidth / 2f

            wavePath.moveTo(tankRect.left, tankRect.bottom)
            wavePath.lineTo(currentTankLeft, waterTopPixelY)

            val waveAmplitude = tankRect.width() * 0.02f
            val waveLength = currentTankWidth
            val horizontalOffset = waveOffset * waveLength
            val segments = 20
            for (i in 0..segments) {
                val x = currentTankLeft + i * (currentTankWidth / segments)
                val y = waterTopPixelY + (waveAmplitude * sin(((x + horizontalOffset) / waveLength * 2 * Math.PI))).toFloat()
                wavePath.lineTo(x, y)
            }

            wavePath.lineTo(currentTankRight, waterTopPixelY)
            wavePath.lineTo(tankRect.right, tankRect.bottom)
            wavePath.close()

            canvas.drawPath(wavePath, waterPaint)
        }

        // CHANGED: Adjusted Y positions to create more space between the text lines
        val centerX = tankRect.centerX()
        val centerY = tankRect.centerY()
        val percentTextY = centerY - (percentageTextPaint.descent() + percentageTextPaint.ascent()) / 2 - 40f
        val cmTextY = centerY - (cmTextPaint.descent() + cmTextPaint.ascent()) / 2 + 85f

        canvas.drawText("${waterLevelPercent.toInt()}%", centerX, percentTextY, percentageTextPaint)
        canvas.drawText(String.format(Locale.US, "%.1f cm", waterLevelCm), centerX, cmTextY, cmTextPaint)

        canvas.restore()
        canvas.drawPath(tankShapePath, borderPaint)
    }

    private fun calculateTankWidthAtY(y: Float): Float {
        val height = tankRect.height()
        val neckBottomY = tankRect.top + height * neckHeightRatio
        val shoulderBottomY = neckBottomY + height * shoulderHeightRatio

        val neckWidth = tankRect.width() * neckWidthRatio
        val bodyWidth = tankRect.width()

        return when {
            y <= neckBottomY -> neckWidth
            y >= shoulderBottomY -> bodyWidth
            else -> {
                val fraction = (y - neckBottomY) / (shoulderBottomY - neckBottomY)
                val easedFraction = (sin((fraction - 0.5) * Math.PI) / 2.0 + 0.5).toFloat()
                neckWidth + (bodyWidth - neckWidth) * easedFraction
            }
        }
    }

    fun setWaterLevel(percentage: Int, cm: Float) {
        levelAnimator?.cancel()
        val targetPercentage = percentage.coerceIn(0, 100).toFloat()
        val targetCm = cm

        if (targetPercentage == waterLevelPercent && targetCm == waterLevelCm) {
            return
        }

        val startPercent = waterLevelPercent
        val startCm = waterLevelCm

        levelAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            addUpdateListener { animator ->
                val fraction = animator.animatedFraction
                waterLevelPercent = startPercent + (targetPercentage - startPercent) * fraction
                waterLevelCm = startCm + (targetCm - startCm) * fraction
                invalidate()
            }
            start()
        }
    }
}