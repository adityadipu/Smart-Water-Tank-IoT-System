package com.iot.smartwatertank

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Use a Handler to delay the start of the MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            // Create an Intent to start MainActivity
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)

            // Finish the SplashActivity so the user can't navigate back to it
            finish()
        }, 2000) // 2000 milliseconds = 2 seconds
    }
}
