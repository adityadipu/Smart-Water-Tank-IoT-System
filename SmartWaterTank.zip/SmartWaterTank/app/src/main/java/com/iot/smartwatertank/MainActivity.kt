package com.iot.smartwatertank

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.gson.Gson
import com.iot.smartwatertank.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var mqttService: MqttService? = null
    private var isBound = false
    private val TAG = "MainActivity"

    private val timerHandler = Handler(Looper.getMainLooper())
    private var isTimerRunning = false

    // --- Timer logic remains the same ---
    private fun createTimerRunnable(startTime: Long): Runnable {
        return object : Runnable {
            override fun run() {
                val elapsedMillis = System.currentTimeMillis() - startTime
                val hours = TimeUnit.MILLISECONDS.toHours(elapsedMillis)
                val minutes = TimeUnit.MILLISECONDS.toMinutes(elapsedMillis) % 60
                val seconds = TimeUnit.MILLISECONDS.toSeconds(elapsedMillis) % 60
                binding.textViewPumpTimer.text =
                    String.format("Running for: %02d:%02d:%02d", hours, minutes, seconds)
                timerHandler.postDelayed(this, 1000)
            }
        }
    }

    // --- MODIFIED: The ServiceConnection now requests a status update ---
    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as MqttService.MqttBinder
            mqttService = binder.getService()
            isBound = true
            Log.d(TAG, "MqttService bound")

            // NEW: Ask the service for its current status
            mqttService?.requestStatusUpdate()
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            mqttService = null // Also clear the service instance
        }
    }

    // --- MODIFIED: The BroadcastReceiver now handles the message correctly ---
    private val mqttReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                MqttConstants.ACTION_MQTT_CONNECTION_STATUS -> {
                    val isConnected = intent.getBooleanExtra(
                        MqttConstants.EXTRA_CONNECTION_STATUS,
                        false
                    )
                    // NEW: Get the detailed message from the service
                    val message = intent.getStringExtra(MqttConstants.EXTRA_STATUS_MESSAGE)
                        ?: "Disconnected"
                    updateConnectionStatus(isConnected, message) // Pass both parameters
                }

                MqttConstants.ACTION_MQTT_MSG_RECEIVED -> {
                    val message = intent.getStringExtra(MqttConstants.EXTRA_MESSAGE)
                    val receivedTimestamp = intent.getLongExtra(
                        MqttConstants.EXTRA_PUMP_ON_TIMESTAMP,
                        0L
                    )
                    message?.let {
                        try {
                            val tankData = Gson().fromJson(it, TankData::class.java)
                            updateUi(tankData, receivedTimestamp)
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to parse JSON in broadcast", e)
                        }
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val serviceIntent = Intent(this, MqttService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)

        setupBottomNavigation()
        setupButtonClickListeners()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(MqttConstants.ACTION_MQTT_MSG_RECEIVED)
            addAction(MqttConstants.ACTION_MQTT_CONNECTION_STATUS)
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(mqttReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        binding.bottomNavigation.selectedItemId = R.id.navigation_home
        loadAndDisplayThresholds()

        // This line is now handled by onServiceConnected, ensuring it runs at the right time.
        // mqttService?.requestStatusUpdate()
    }

    override fun onPause() {
        super.onPause()
        timerHandler.removeCallbacksAndMessages(null)
        isTimerRunning = false
    }

    override fun onStop() {
        super.onStop()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mqttReceiver)
    }

    private fun loadAndDisplayThresholds() {
        val prefs = getSharedPreferences(MqttConstants.PREFS_NAME, Context.MODE_PRIVATE)
        val minLevel = prefs.getInt(MqttConstants.KEY_MIN_LEVEL, 20)
        val maxLevel = prefs.getInt(MqttConstants.KEY_MAX_LEVEL, 95)
        binding.textViewOnThreshold.text = "ON at: $minLevel%"
        binding.textViewOffThreshold.text = "OFF at: $maxLevel%"
    }

    private fun setupButtonClickListeners() {
        val commandTopic = "iot-projects/water-tank-123/command"

        binding.buttonStop.setOnClickListener {
            Log.d(TAG, "STOP button clicked")
            Toast.makeText(this, "🚨 EMERGENCY STOP Activated", Toast.LENGTH_LONG).show()
            mqttService?.publish(commandTopic, "STOP")
        }

        binding.buttonPumpOn.setOnClickListener {
            Log.d(TAG, "Pump ON button clicked")
            Toast.makeText(this, "🔄 Pump ON Command Sent", Toast.LENGTH_SHORT).show()
            mqttService?.publish(commandTopic, "PUMP_ON")
        }

        binding.buttonPumpOff.setOnClickListener {
            Log.d(TAG, "Pump OFF button clicked")
            Toast.makeText(this, "⏹️ Pump OFF Command Sent", Toast.LENGTH_SHORT).show()
            mqttService?.publish(commandTopic, "PUMP_OFF")
        }

        binding.buttonAuto.setOnClickListener {
            Log.d(TAG, "AUTO button clicked")
            Toast.makeText(this, "🤖 Auto Mode Activated", Toast.LENGTH_SHORT).show()
            mqttService?.publish(commandTopic, "PUMP_AUTO")
        }
    }

    private fun updateUi(tankData: TankData, pumpOnTimestamp: Long) {
        binding.waterTankView.setWaterLevel(tankData.level_percentage, tankData.level_cm)
        binding.textViewPumpStatus.text = "PUMP STATUS: ${tankData.pump_status}"

        if (tankData.pump_status == "ON" && pumpOnTimestamp > 0L) {
            if (!isTimerRunning) {
                binding.textViewPumpTimer.visibility = View.VISIBLE
                timerHandler.post(createTimerRunnable(pumpOnTimestamp))
                isTimerRunning = true
            }
        } else {
            timerHandler.removeCallbacksAndMessages(null)
            binding.textViewPumpTimer.visibility = View.GONE
            isTimerRunning = false
        }
    }

    // --- MODIFIED: updateConnectionStatus now uses the message from the service ---
    private fun updateConnectionStatus(isConnected: Boolean, message: String) {
        binding.textViewStatus.text = message // Use the message from the service
        val color = ContextCompat.getColor(
            this,
            if (isConnected) R.color.green_on else R.color.red_off
        )
        val icon = if (isConnected) R.drawable.ic_wifi else R.drawable.ic_wifi_off
        binding.textViewStatus.setTextColor(color)
        binding.imageViewStatusIcon.setImageResource(icon)
        binding.imageViewStatusIcon.setColorFilter(color)
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> true
                R.id.navigation_dashboard -> {
                    startActivity(Intent(this, DashboardActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    })
                    true
                }
                R.id.navigation_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    })
                    true
                }
                else -> false
            }
        }
    }
}