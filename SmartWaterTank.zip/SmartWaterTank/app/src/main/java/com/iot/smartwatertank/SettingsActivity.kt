package com.iot.smartwatertank

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.gson.Gson
import com.iot.smartwatertank.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var mqttService: MqttService? = null
    private var isBound = false
    private val TAG = "SettingsActivity"

    data class ConfigData(val min_level: Int, val max_level: Int)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as MqttService.MqttBinder
            mqttService = binder.getService()
            isBound = true
            Log.d(TAG, "MqttService connected")
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
            mqttService = null
            Log.d(TAG, "MqttService disconnected")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Settings"

        // --- NEW: Added missing function call ---
        setupBottomNavigation()
        loadSettings()

        binding.buttonSaveSettings.setOnClickListener {
            saveAndPublishSettings()
        }
    }

    override fun onResume() {
        super.onResume()
        // --- NEW: Find bottom_navigation through binding ---
        findViewById<BottomNavigationView>(R.id.bottom_navigation).selectedItemId = R.id.navigation_settings
    }

    override fun onStart() {
        super.onStart()
        Intent(this, MqttService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        if (isBound) {
            unbindService(connection)
            isBound = false
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        startActivity(intent)
        overridePendingTransition(0, 0)
        return true
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("PumpSettings", Context.MODE_PRIVATE)
        val minLevel = prefs.getInt("MIN_LEVEL", 20)
        val maxLevel = prefs.getInt("MAX_LEVEL", 95)

        binding.editTextPumpOn.setText(minLevel.toString())
        binding.editTextPumpOff.setText(maxLevel.toString())
    }

    private fun saveAndPublishSettings() {
        val minLevelStr = binding.editTextPumpOn.text.toString()
        val maxLevelStr = binding.editTextPumpOff.text.toString()

        if (minLevelStr.isBlank() || maxLevelStr.isBlank()) {
            Toast.makeText(this, "Thresholds cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        val minLevel = minLevelStr.toInt()
        val maxLevel = maxLevelStr.toInt()

        if (minLevel >= maxLevel) {
            Toast.makeText(this, "ON threshold must be less than OFF threshold", Toast.LENGTH_SHORT).show()
            return
        }

        val prefs = getSharedPreferences("PumpSettings", Context.MODE_PRIVATE).edit()
        prefs.putInt("MIN_LEVEL", minLevel)
        prefs.putInt("MAX_LEVEL", maxLevel)
        prefs.apply()

        val configData = ConfigData(min_level = minLevel, max_level = maxLevel)
        val jsonPayload = Gson().toJson(configData)
        val configTopic = "iot-projects/water-tank-123/config"

        if (isBound && mqttService != null) {
            mqttService?.publish(configTopic, jsonPayload)
            Toast.makeText(this, "Settings sent to device!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Error: Service not connected", Toast.LENGTH_SHORT).show()
        }
    }

    // --- NEW: Added the missing navigation setup ---
    private fun setupBottomNavigation() {
        findViewById<BottomNavigationView>(R.id.bottom_navigation).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    startActivity(intent)
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.navigation_dashboard -> {
                    val intent = Intent(this, DashboardActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    startActivity(intent)
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.navigation_settings -> {
                    true
                }
                else -> false
            }
        }
    }
}