package com.iot.smartwatertank

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pump_events")
data class PumpEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val status: String // "ON" or "OFF"
)