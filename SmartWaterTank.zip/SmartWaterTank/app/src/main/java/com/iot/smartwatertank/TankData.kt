package com.iot.smartwatertank

import com.google.gson.annotations.SerializedName

data class TankData(
    val level_cm: Float,
    val level_percentage: Int,
    val pump_status: String
)