pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // This line is required for MPAndroidChart
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "SmartWaterTank"
include(":app")